# InterviewAI — AI-Powered Interview Preparation Platform

InterviewAI is a full-stack GenAI platform that helps job seekers prepare for interviews by analyzing a resume and target job description. Users can upload a resume PDF, paste a job description, and generate personalized technical, behavioral, and scenario-based interview questions with AI-generated sample answers.

## Features

- User registration and login with JWT authentication
- Resume PDF upload and text extraction
- Job description analysis
- Resume-to-job skill matching
- AI-generated technical, behavioral, and scenario-based questions
- AI-generated sample answers based on resume experience
- Interview history tracking
- Analytics dashboard
- Dockerized frontend, backend, and PostgreSQL database

## Tech Stack

### Frontend
- React
- TypeScript
- Tailwind CSS
- Recharts
- Axios

### Backend
- FastAPI
- Python
- SQLAlchemy
- PostgreSQL
- JWT Authentication
- PyMuPDF for PDF parsing

### AI
- OpenAI API
- LangChain-ready architecture
- Prompt Engineering
- Resume/JD skill matching

### Deployment
- Docker
- Docker Compose
- Vercel / Render / AWS-ready structure

## Architecture

```text
User
  ↓
React + TypeScript Frontend
  ↓
FastAPI Backend
  ↓
PostgreSQL Database
  ↓
Resume Parser + Skill Matcher + OpenAI Service
  ↓
AI-generated questions, answers, missing skills, and match score
```

## Project Structure

```text
interviewai-platform/
├── backend/
│   ├── app/
│   │   ├── main.py
│   │   ├── database.py
│   │   ├── models.py
│   │   ├── schemas.py
│   │   ├── config.py
│   │   ├── routers/
│   │   ├── services/
│   │   └── utils/
│   ├── requirements.txt
│   ├── Dockerfile
│   └── .env.example
├── frontend/
│   ├── src/
│   │   ├── api/
│   │   ├── components/
│   │   ├── pages/
│   │   └── styles/
│   ├── package.json
│   └── Dockerfile
├── docker-compose.yml
└── README.md
```

## Local Setup Without Docker

### Backend

```bash
cd backend
python -m venv venv
source venv/bin/activate   # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload
```

Backend runs at:

```text
http://localhost:8000
```

API docs:

```text
http://localhost:8000/docs
```

### Frontend

```bash
cd frontend
npm install
npm run dev
```

Frontend runs at:

```text
http://localhost:5173
```

## Local Setup With Docker

Create `backend/.env`:

```env
DATABASE_URL=postgresql://postgres:postgres@db:5432/interviewai
OPENAI_API_KEY=your_openai_api_key
JWT_SECRET_KEY=change_this_secret
ACCESS_TOKEN_EXPIRE_MINUTES=1440
```

Run:

```bash
docker compose up --build
```

## Important Note About OpenAI API Key

If `OPENAI_API_KEY` is not provided, the backend still works using fallback interview questions. Add your OpenAI API key to generate real AI-powered responses.

## API Endpoints

### Auth

```text
POST /auth/register
POST /auth/login
GET  /auth/me
```

### Resume

```text
POST /resume/upload
GET  /resume/list
```

### Interview

```text
POST /interview/generate
GET  /interview/history
GET  /interview/{session_id}
```

### Analytics

```text
GET /analytics/summary
```

## Resume Bullet Points

- Built a full-stack GenAI interview preparation platform using React, TypeScript, FastAPI, PostgreSQL, OpenAI API, and JWT authentication to generate personalized interview questions from resumes and job descriptions.
- Implemented resume PDF parsing, job description analysis, AI prompt workflows, skill matching, and structured question generation for technical, behavioral, and scenario-based interview preparation.
- Designed interview history tracking and analytics dashboards to help users monitor preparation progress, skill match scores, and missing skills across multiple job applications.
- Dockerized frontend, backend, and database services using Docker Compose, enabling reproducible local development and cloud-ready deployment.

## Future Improvements

- Voice-based mock interview practice
- Resume ATS score analyzer
- LinkedIn profile analyzer
- Video interview feedback
- RAG-based resume improvement assistant
- Multi-language interview preparation

## License

MIT License

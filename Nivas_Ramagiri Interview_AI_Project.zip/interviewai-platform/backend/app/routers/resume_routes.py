from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import Resume, User
from ..schemas import ResumeOut
from ..services.resume_parser import extract_pdf_text
from ..utils.security import get_current_user

router = APIRouter(prefix="/resume", tags=["Resume"])


@router.post("/upload", response_model=ResumeOut)
async def upload_resume(file: UploadFile = File(...), db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    if not file.filename.lower().endswith(".pdf"):
        raise HTTPException(status_code=400, detail="Only PDF resumes are supported")
    try:
        text = await extract_pdf_text(file)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    resume = Resume(user_id=current_user.id, file_name=file.filename, extracted_text=text)
    db.add(resume)
    db.commit()
    db.refresh(resume)
    return resume


@router.get("/list", response_model=list[ResumeOut])
def list_resumes(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    return db.query(Resume).filter(Resume.user_id == current_user.id).order_by(Resume.uploaded_at.desc()).all()

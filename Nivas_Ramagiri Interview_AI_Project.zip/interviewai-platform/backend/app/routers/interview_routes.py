from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import InterviewQuestion, InterviewSession, Resume, User
from ..schemas import InterviewCreate, InterviewOut
from ..services.ai_service import generate_interview_content
from ..services.jd_matcher import calculate_skill_match
from ..utils.security import get_current_user

router = APIRouter(prefix="/interview", tags=["Interview"])


@router.post("/generate", response_model=InterviewOut)
def generate_interview(payload: InterviewCreate, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    resume = db.query(Resume).filter(Resume.id == payload.resume_id, Resume.user_id == current_user.id).first()
    if not resume:
        raise HTTPException(status_code=404, detail="Resume not found")

    score, matched, missing = calculate_skill_match(resume.extracted_text, payload.job_description)
    ai_data = generate_interview_content(resume.extracted_text, payload.job_description, payload.job_title, score, missing)

    session = InterviewSession(
        user_id=current_user.id,
        resume_id=resume.id,
        job_title=payload.job_title,
        company_name=payload.company_name,
        job_description=payload.job_description,
        skill_match_score=float(ai_data.get("skill_match_score", score)),
        missing_skills=", ".join(ai_data.get("missing_skills", missing)),
    )
    db.add(session)
    db.commit()
    db.refresh(session)

    for item in ai_data.get("questions", []):
        db.add(InterviewQuestion(
            session_id=session.id,
            question_type=item.get("question_type", "Technical"),
            question=item.get("question", ""),
            sample_answer=item.get("sample_answer", ""),
        ))
    db.commit()
    db.refresh(session)
    return session


@router.get("/history", response_model=list[InterviewOut])
def history(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    return db.query(InterviewSession).filter(InterviewSession.user_id == current_user.id).order_by(InterviewSession.created_at.desc()).all()


@router.get("/{session_id}", response_model=InterviewOut)
def get_session(session_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    session = db.query(InterviewSession).filter(InterviewSession.id == session_id, InterviewSession.user_id == current_user.id).first()
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    return session

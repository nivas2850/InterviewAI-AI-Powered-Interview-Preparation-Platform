from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    DATABASE_URL: str = "sqlite:///./interviewai.db"
    OPENAI_API_KEY: str = ""
    JWT_SECRET_KEY: str = "change_this_secret"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 1440

    class Config:
        env_file = ".env"


settings = Settings()

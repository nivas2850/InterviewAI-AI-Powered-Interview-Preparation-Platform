from datetime import datetime
from typing import List, Optional
from pydantic import BaseModel, EmailStr


class UserCreate(BaseModel):
    name: str
    email: EmailStr
    password: str


class UserLogin(BaseModel):
    email: EmailStr
    password: str


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"


class UserOut(BaseModel):
    id: int
    name: str
    email: str

    class Config:
        from_attributes = True


class ResumeOut(BaseModel):
    id: int
    file_name: str
    uploaded_at: datetime

    class Config:
        from_attributes = True


class InterviewCreate(BaseModel):
    resume_id: int
    job_title: str
    company_name: Optional[str] = None
    job_description: str


class QuestionOut(BaseModel):
    id: int
    question_type: str
    question: str
    sample_answer: str

    class Config:
        from_attributes = True


class InterviewOut(BaseModel):
    id: int
    job_title: str
    company_name: Optional[str]
    skill_match_score: float
    missing_skills: str
    created_at: datetime
    questions: List[QuestionOut] = []

    class Config:
        from_attributes = True

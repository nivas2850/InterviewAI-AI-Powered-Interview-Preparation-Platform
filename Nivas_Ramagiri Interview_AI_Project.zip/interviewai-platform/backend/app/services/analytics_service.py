from sqlalchemy.orm import Session
from ..models import InterviewSession, InterviewQuestion, User


def get_user_summary(db: Session, user: User) -> dict:
    sessions = db.query(InterviewSession).filter(InterviewSession.user_id == user.id).all()
    total_questions = (
        db.query(InterviewQuestion)
        .join(InterviewSession)
        .filter(InterviewSession.user_id == user.id)
        .count()
    )
    avg_match = 0 if not sessions else round(sum(s.skill_match_score for s in sessions) / len(sessions), 2)
    return {
        "total_sessions": len(sessions),
        "total_questions": total_questions,
        "average_skill_match": avg_match,
        "latest_sessions": [
            {"id": s.id, "job_title": s.job_title, "company_name": s.company_name, "skill_match_score": s.skill_match_score}
            for s in sessions[-5:]
        ],
    }

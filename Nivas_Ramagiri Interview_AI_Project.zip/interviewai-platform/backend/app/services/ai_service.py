import json
from openai import OpenAI
from ..config import settings


def fallback_questions(job_title: str, match_score: float, missing_skills: list[str]) -> dict:
    return {
        "skill_match_score": match_score,
        "missing_skills": missing_skills,
        "questions": [
            {
                "question_type": "Technical",
                "question": f"Explain how you would design a scalable backend system for a {job_title} role.",
                "sample_answer": "I would start by understanding the functional and non-functional requirements, then design REST APIs, database schema, authentication, observability, and deployment. I would use FastAPI or Spring Boot for services, PostgreSQL for structured data, Docker for packaging, and cloud deployment for scalability."
            },
            {
                "question_type": "Technical",
                "question": "How would you integrate an LLM into a full-stack application?",
                "sample_answer": "I would create a backend AI service that receives user input, builds a structured prompt, calls the LLM API, validates the response, stores results in the database, and returns a clean response to the frontend. I would also add rate limiting, logging, and error handling."
            },
            {
                "question_type": "Behavioral",
                "question": "Tell me about a time you solved a difficult technical problem.",
                "sample_answer": "In a previous project, I handled performance issues in a distributed system by analyzing logs, identifying bottlenecks, optimizing queries, and improving service communication. This reduced latency and improved reliability for users."
            },
            {
                "question_type": "Scenario",
                "question": "Your AI-generated answers are inaccurate. How would you fix the issue?",
                "sample_answer": "I would inspect the prompt, validate the source data, add better context, use structured outputs, evaluate hallucination patterns, and improve retrieval or matching logic. I would also add human review for critical outputs."
            }
        ]
    }


def generate_interview_content(resume_text: str, job_description: str, job_title: str, match_score: float, missing_skills: list[str]) -> dict:
    if not settings.OPENAI_API_KEY:
        return fallback_questions(job_title, match_score, missing_skills)

    client = OpenAI(api_key=settings.OPENAI_API_KEY)
    prompt = f"""
You are an expert technical interviewer and career coach.
Analyze the candidate resume and job description.
Return ONLY valid JSON with this schema:
{{
  "skill_match_score": number,
  "missing_skills": ["skill1"],
  "questions": [
    {{"question_type": "Technical|Behavioral|Scenario", "question": "...", "sample_answer": "..."}}
  ]
}}
Generate 8 technical questions, 5 behavioral questions, and 5 scenario-based questions.
Make answers sound natural and based on the resume.

Resume:
{resume_text[:7000]}

Job Description:
{job_description[:5000]}

Initial skill match score: {match_score}
Missing skills: {missing_skills}
"""
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.4,
    )
    content = response.choices[0].message.content or "{}"
    try:
        return json.loads(content)
    except json.JSONDecodeError:
        return fallback_questions(job_title, match_score, missing_skills)

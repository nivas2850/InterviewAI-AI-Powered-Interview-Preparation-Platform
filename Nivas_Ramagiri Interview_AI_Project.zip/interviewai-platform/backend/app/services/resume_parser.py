import fitz
from fastapi import UploadFile


async def extract_pdf_text(file: UploadFile) -> str:
    content = await file.read()
    text_parts: list[str] = []
    with fitz.open(stream=content, filetype="pdf") as doc:
        for page in doc:
            text_parts.append(page.get_text())
    extracted = "\n".join(text_parts).strip()
    if not extracted:
        raise ValueError("No text could be extracted from the PDF.")
    return extracted

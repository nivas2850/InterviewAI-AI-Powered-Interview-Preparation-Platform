import re

COMMON_SKILLS = [
    "python", "java", "typescript", "react", "fastapi", "node", "postgresql", "sql",
    "aws", "docker", "kubernetes", "mlflow", "airflow", "langchain", "openai",
    "rag", "llm", "machine learning", "deep learning", "nlp", "tensorflow", "pytorch",
    "scikit-learn", "xgboost", "kafka", "microservices", "jwt", "rest api"
]


def normalize(text: str) -> str:
    return re.sub(r"\s+", " ", text.lower())


def calculate_skill_match(resume_text: str, job_description: str) -> tuple[float, list[str], list[str]]:
    resume = normalize(resume_text)
    jd = normalize(job_description)
    jd_skills = [skill for skill in COMMON_SKILLS if skill in jd]
    if not jd_skills:
        return 50.0, [], []
    matched = [skill for skill in jd_skills if skill in resume]
    missing = [skill for skill in jd_skills if skill not in resume]
    score = round((len(matched) / len(jd_skills)) * 100, 2)
    return score, matched, missing

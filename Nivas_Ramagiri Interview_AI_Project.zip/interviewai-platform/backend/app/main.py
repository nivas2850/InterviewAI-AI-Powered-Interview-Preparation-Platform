from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .database import Base, engine
from .routers import analytics_routes, auth_routes, interview_routes, resume_routes

Base.metadata.create_all(bind=engine)

app = FastAPI(title="InterviewAI API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://localhost:3000", "*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth_routes.router)
app.include_router(resume_routes.router)
app.include_router(interview_routes.router)
app.include_router(analytics_routes.router)


@app.get("/")
def root():
    return {"message": "InterviewAI API is running"}

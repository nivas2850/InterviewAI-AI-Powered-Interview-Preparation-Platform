import { FormEvent, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import api from '../api/axios';

export default function Login() {
  const [email, setEmail] = useState(''); const [password, setPassword] = useState(''); const [error, setError] = useState('');
  const navigate = useNavigate();
  async function submit(e: FormEvent) { e.preventDefault(); setError(''); try { const res = await api.post('/auth/login', { email, password }); localStorage.setItem('token', res.data.access_token); navigate('/dashboard'); } catch { setError('Invalid login'); } }
  return <main className="min-h-screen flex items-center justify-center p-6"><form onSubmit={submit} className="card w-full max-w-md"><h1 className="text-3xl font-black">Login</h1><p className="mt-2 text-slate-600">Prepare smarter with AI.</p>{error && <p className="mt-3 text-red-600">{error}</p>}<input className="input mt-6" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} /><input className="input mt-3" type="password" placeholder="Password" value={password} onChange={e=>setPassword(e.target.value)} /><button className="btn mt-5 w-full">Login</button><p className="mt-4 text-sm">No account? <Link className="font-bold" to="/register">Register</Link></p></form></main>
}

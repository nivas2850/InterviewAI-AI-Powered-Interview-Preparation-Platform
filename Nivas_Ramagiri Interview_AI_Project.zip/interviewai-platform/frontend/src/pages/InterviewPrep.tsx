import { FormEvent, useEffect, useState } from 'react';
import api from '../api/axios';
import Navbar from '../components/Navbar';
import QuestionCard from '../components/QuestionCard';
import SkillMatchCard from '../components/SkillMatchCard';

type Resume = { id:number; file_name:string };
type Question = { id:number; question_type:string; question:string; sample_answer:string };
type Result = { skill_match_score:number; missing_skills:string; questions: Question[] };

export default function InterviewPrep(){
 const [resumes,setResumes]=useState<Resume[]>([]); const [resumeId,setResumeId]=useState(''); const [jobTitle,setJobTitle]=useState(''); const [company,setCompany]=useState(''); const [jd,setJd]=useState(''); const [result,setResult]=useState<Result|null>(null); const [loading,setLoading]=useState(false);
 useEffect(()=>{api.get('/resume/list').then(r=>{setResumes(r.data); if(r.data[0]) setResumeId(String(r.data[0].id));});},[]);
 async function submit(e: FormEvent){e.preventDefault(); setLoading(true); const res=await api.post('/interview/generate',{resume_id:Number(resumeId),job_title:jobTitle,company_name:company,job_description:jd}); setResult(res.data); setLoading(false);}
 return <><Navbar/><main className="p-8 max-w-6xl mx-auto"><h1 className="text-4xl font-black">Generate Interview Prep</h1><form onSubmit={submit} className="card mt-6 grid gap-4"><select className="input" value={resumeId} onChange={e=>setResumeId(e.target.value)}>{resumes.map(r=><option key={r.id} value={r.id}>{r.file_name}</option>)}</select><input className="input" placeholder="Job Title" value={jobTitle} onChange={e=>setJobTitle(e.target.value)} /><input className="input" placeholder="Company Name" value={company} onChange={e=>setCompany(e.target.value)} /><textarea className="input min-h-48" placeholder="Paste job description here" value={jd} onChange={e=>setJd(e.target.value)} /><button className="btn" disabled={loading}>{loading ? 'Generating...' : 'Generate Questions'}</button></form>{result && <section className="mt-8"><SkillMatchCard score={result.skill_match_score} missing={result.missing_skills}/><div className="mt-6">{result.questions.map(q=><QuestionCard key={q.id} type={q.question_type} question={q.question} answer={q.sample_answer}/>)}</div></section>}</main></>
}

import { FormEvent, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import api from '../api/axios';

export default function Register() {
  const [name,setName]=useState(''); const [email,setEmail]=useState(''); const [password,setPassword]=useState(''); const navigate=useNavigate();
  async function submit(e: FormEvent){ e.preventDefault(); await api.post('/auth/register',{name,email,password}); navigate('/login'); }
  return <main className="min-h-screen flex items-center justify-center p-6"><form onSubmit={submit} className="card w-full max-w-md"><h1 className="text-3xl font-black">Create Account</h1><input className="input mt-6" placeholder="Name" value={name} onChange={e=>setName(e.target.value)} /><input className="input mt-3" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} /><input className="input mt-3" type="password" placeholder="Password" value={password} onChange={e=>setPassword(e.target.value)} /><button className="btn mt-5 w-full">Register</button><p className="mt-4 text-sm">Already have account? <Link className="font-bold" to="/login">Login</Link></p></form></main>
}

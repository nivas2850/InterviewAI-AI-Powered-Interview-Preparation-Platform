import { useEffect, useState } from 'react';
import api from '../api/axios';
import Navbar from '../components/Navbar';
import QuestionCard from '../components/QuestionCard';

type Session = { id:number; job_title:string; company_name:string; skill_match_score:number; missing_skills:string; questions:{id:number;question_type:string;question:string;sample_answer:string}[] };
export default function History(){
 const [sessions,setSessions]=useState<Session[]>([]);
 useEffect(()=>{api.get('/interview/history').then(r=>setSessions(r.data));},[]);
 return <><Navbar/><main className="p-8 max-w-6xl mx-auto"><h1 className="text-4xl font-black">Interview History</h1>{sessions.map(s=><section key={s.id} className="mt-6"><div className="card"><h2 className="text-2xl font-black">{s.job_title} {s.company_name && `— ${s.company_name}`}</h2><p className="mt-2 text-slate-600">Match Score: <b>{s.skill_match_score}%</b></p><p className="text-slate-600">Missing Skills: {s.missing_skills || 'None'}</p></div>{s.questions.map(q=><QuestionCard key={q.id} type={q.question_type} question={q.question} answer={q.sample_answer}/>)}</section>)}</main></>
}

import { FormEvent, useState } from 'react';
import api from '../api/axios';
import Navbar from '../components/Navbar';

export default function UploadResume(){
 const [file,setFile]=useState<File|null>(null); const [message,setMessage]=useState('');
 async function submit(e: FormEvent){e.preventDefault(); if(!file) return; const form=new FormData(); form.append('file',file); await api.post('/resume/upload',form); setMessage('Resume uploaded successfully');}
 return <><Navbar/><main className="p-8 max-w-3xl mx-auto"><h1 className="text-4xl font-black">Upload Resume</h1><form onSubmit={submit} className="card mt-6"><input className="input" type="file" accept="application/pdf" onChange={e=>setFile(e.target.files?.[0] || null)} /><button className="btn mt-5">Upload PDF</button>{message && <p className="mt-4 text-green-700 font-bold">{message}</p>}</form></main></>
}

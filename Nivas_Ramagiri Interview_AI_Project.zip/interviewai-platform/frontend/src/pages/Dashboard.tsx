import { useEffect, useState } from 'react';
import api from '../api/axios';
import Navbar from '../components/Navbar';
import AnalyticsChart from '../components/AnalyticsChart';

export default function Dashboard(){
  const [data,setData]=useState({total_sessions:0,total_questions:0,average_skill_match:0,latest_sessions:[]});
  useEffect(()=>{api.get('/analytics/summary').then(r=>setData(r.data)).catch(()=>{});},[]);
  return <><Navbar/><main className="p-8 max-w-6xl mx-auto"><h1 className="text-4xl font-black">Dashboard</h1><div className="grid md:grid-cols-3 gap-5 mt-6"><div className="card"><p>Total Sessions</p><h2 className="text-4xl font-black">{data.total_sessions}</h2></div><div className="card"><p>Total Questions</p><h2 className="text-4xl font-black">{data.total_questions}</h2></div><div className="card"><p>Average Match</p><h2 className="text-4xl font-black">{data.average_skill_match}%</h2></div></div><div className="mt-6"><AnalyticsChart totalSessions={data.total_sessions} totalQuestions={data.total_questions} avgMatch={data.average_skill_match}/></div></main></>
}

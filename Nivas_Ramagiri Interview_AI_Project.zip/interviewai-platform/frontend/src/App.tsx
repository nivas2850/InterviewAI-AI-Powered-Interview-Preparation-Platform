import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import Dashboard from './pages/Dashboard';
import History from './pages/History';
import InterviewPrep from './pages/InterviewPrep';
import Login from './pages/Login';
import Register from './pages/Register';
import UploadResume from './pages/UploadResume';

function PrivateRoute({ children }: { children: JSX.Element }) {
  return localStorage.getItem('token') ? children : <Navigate to="/login" />;
}

export default function App(){
 return <BrowserRouter><Routes><Route path="/" element={<Navigate to="/dashboard"/>}/><Route path="/login" element={<Login/>}/><Route path="/register" element={<Register/>}/><Route path="/dashboard" element={<PrivateRoute><Dashboard/></PrivateRoute>}/><Route path="/upload" element={<PrivateRoute><UploadResume/></PrivateRoute>}/><Route path="/prepare" element={<PrivateRoute><InterviewPrep/></PrivateRoute>}/><Route path="/history" element={<PrivateRoute><History/></PrivateRoute>}/></Routes></BrowserRouter>
}

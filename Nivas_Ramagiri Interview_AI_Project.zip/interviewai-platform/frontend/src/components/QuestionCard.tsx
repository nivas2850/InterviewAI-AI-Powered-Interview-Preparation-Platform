type Props = { type: string; question: string; answer: string };
export default function QuestionCard({ type, question, answer }: Props) {
  return <div className="card my-4">
    <span className="text-xs font-bold uppercase tracking-wide text-slate-500">{type}</span>
    <h3 className="mt-2 text-lg font-bold text-slate-900">{question}</h3>
    <p className="mt-3 leading-7 text-slate-700">{answer}</p>
  </div>
}

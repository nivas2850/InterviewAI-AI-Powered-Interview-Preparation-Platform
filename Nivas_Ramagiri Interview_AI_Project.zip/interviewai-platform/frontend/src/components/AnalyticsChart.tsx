import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';

type Props = { totalSessions: number; totalQuestions: number; avgMatch: number };
export default function AnalyticsChart({ totalSessions, totalQuestions, avgMatch }: Props) {
  const data = [{ name: 'Sessions', value: totalSessions }, { name: 'Questions', value: totalQuestions }, { name: 'Avg Match', value: avgMatch }];
  return <div className="card h-80"><ResponsiveContainer width="100%" height="100%"><BarChart data={data}><CartesianGrid strokeDasharray="3 3"/><XAxis dataKey="name"/><YAxis/><Tooltip/><Bar dataKey="value" /></BarChart></ResponsiveContainer></div>
}

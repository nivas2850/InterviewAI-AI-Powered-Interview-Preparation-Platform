import { Link, useNavigate } from 'react-router-dom';

export default function Navbar() {
  const navigate = useNavigate();
  const logout = () => { localStorage.removeItem('token'); navigate('/login'); };
  return <nav className="bg-white border-b border-slate-200 px-8 py-4 flex justify-between items-center">
    <Link to="/" className="text-2xl font-bold text-slate-900">InterviewAI</Link>
    <div className="flex gap-5 text-sm font-medium">
      <Link to="/dashboard">Dashboard</Link><Link to="/upload">Resume</Link><Link to="/prepare">Prepare</Link><Link to="/history">History</Link>
      <button onClick={logout} className="text-red-600">Logout</button>
    </div>
  </nav>
}

type Props = { score: number; missing: string };
export default function SkillMatchCard({ score, missing }: Props) {
  return <div className="card">
    <p className="text-sm text-slate-500">Resume to JD Match</p>
    <h2 className="mt-2 text-5xl font-black text-slate-900">{score}%</h2>
    <p className="mt-4 text-sm text-slate-600"><b>Missing Skills:</b> {missing || 'None detected'}</p>
  </div>
}
